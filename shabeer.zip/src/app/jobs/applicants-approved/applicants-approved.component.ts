import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicants-approved',
  templateUrl: './applicants-approved.component.html',
  styleUrls: ['./applicants-approved.component.css']
})
export class ApplicantsApprovedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
