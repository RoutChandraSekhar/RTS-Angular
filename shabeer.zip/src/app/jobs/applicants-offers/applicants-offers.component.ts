import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicants-offers',
  templateUrl: './applicants-offers.component.html',
  styleUrls: ['./applicants-offers.component.css']
})
export class ApplicantsOffersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
