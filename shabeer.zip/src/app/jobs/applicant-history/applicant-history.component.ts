import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicant-history',
  templateUrl: './applicant-history.component.html',
  styleUrls: ['./applicant-history.component.css']
})
export class ApplicantHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  

}
