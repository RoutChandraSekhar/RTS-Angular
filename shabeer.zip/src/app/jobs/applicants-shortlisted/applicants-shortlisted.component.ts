import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicants-shortlisted',
  templateUrl: './applicants-shortlisted.component.html',
  styleUrls: ['./applicants-shortlisted.component.css']
})
export class ApplicantsShortlistedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
