import { Component, OnInit } from '@angular/core';
declare var $:any;
@Component({
  selector: 'app-jobs-home',
  templateUrl: './jobs-home.component.html',
  styleUrls: ['./jobs-home.component.css']
})
export class JobsHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {

  }


}
