import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicants-hired',
  templateUrl: './applicants-hired.component.html',
  styleUrls: ['./applicants-hired.component.css']
})
export class ApplicantsHiredComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
