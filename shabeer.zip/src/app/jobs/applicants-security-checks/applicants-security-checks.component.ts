import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicants-security-checks',
  templateUrl: './applicants-security-checks.component.html',
  styleUrls: ['./applicants-security-checks.component.css']
})
export class ApplicantsSecurityChecksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
