import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicants-joined',
  templateUrl: './applicants-joined.component.html',
  styleUrls: ['./applicants-joined.component.css']
})
export class ApplicantsJoinedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
