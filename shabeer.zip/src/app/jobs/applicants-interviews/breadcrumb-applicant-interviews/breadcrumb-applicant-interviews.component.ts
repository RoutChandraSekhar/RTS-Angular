import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-breadcrumb-applicant-interviews',
  templateUrl: './breadcrumb-applicant-interviews.component.html',
  styleUrls: ['./breadcrumb-applicant-interviews.component.css']
})
export class BreadcrumbApplicantInterviewsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
