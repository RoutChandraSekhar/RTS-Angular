import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-breadcrumb-cv-database',
  templateUrl: './breadcrumb-cv-database.component.html',
  styleUrls: ['./breadcrumb-cv-database.component.css']
})
export class BreadcrumbCvDatabaseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
