import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-candidate-form-academic-profile',
  templateUrl: './add-candidate-form-academic-profile.component.html',
  styleUrls: ['./add-candidate-form-academic-profile.component.css']
})
export class AddCandidateFormAcademicProfileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
