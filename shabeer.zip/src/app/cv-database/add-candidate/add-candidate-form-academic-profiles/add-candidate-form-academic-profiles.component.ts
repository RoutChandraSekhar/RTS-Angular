import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-candidate-form-academic-profiles',
  templateUrl: './add-candidate-form-academic-profiles.component.html',
  styleUrls: ['./add-candidate-form-academic-profiles.component.css']
})
export class AddCandidateFormAcademicProfilesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
