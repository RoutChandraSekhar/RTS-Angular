import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-candidate-form-personal-profile',
  templateUrl: './add-candidate-form-personal-profile.component.html',
  styleUrls: ['./add-candidate-form-personal-profile.component.css']
})
export class AddCandidateFormPersonalProfileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
