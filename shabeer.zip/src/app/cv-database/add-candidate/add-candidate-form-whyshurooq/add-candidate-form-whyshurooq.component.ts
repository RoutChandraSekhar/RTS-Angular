import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-candidate-form-whyshurooq',
  templateUrl: './add-candidate-form-whyshurooq.component.html',
  styleUrls: ['./add-candidate-form-whyshurooq.component.css']
})
export class AddCandidateFormWhyshurooqComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
