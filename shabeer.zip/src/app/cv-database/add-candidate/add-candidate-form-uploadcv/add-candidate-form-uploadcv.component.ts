import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-candidate-form-uploadcv',
  templateUrl: './add-candidate-form-uploadcv.component.html',
  styleUrls: ['./add-candidate-form-uploadcv.component.css']
})
export class AddCandidateFormUploadcvComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
