import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-candidate-form-employment-profile',
  templateUrl: './add-candidate-form-employment-profile.component.html',
  styleUrls: ['./add-candidate-form-employment-profile.component.css']
})
export class AddCandidateFormEmploymentProfileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
