import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-candidate-form-employment-profiles',
  templateUrl: './add-candidate-form-employment-profiles.component.html',
  styleUrls: ['./add-candidate-form-employment-profiles.component.css']
})
export class AddCandidateFormEmploymentProfilesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
