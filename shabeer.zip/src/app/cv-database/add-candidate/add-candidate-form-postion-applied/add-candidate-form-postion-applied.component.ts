import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-candidate-form-postion-applied',
  templateUrl: './add-candidate-form-postion-applied.component.html',
  styleUrls: ['./add-candidate-form-postion-applied.component.css']
})
export class AddCandidateFormPostionAppliedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
