import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-candidate-form-work-experience',
  templateUrl: './add-candidate-form-work-experience.component.html',
  styleUrls: ['./add-candidate-form-work-experience.component.css']
})
export class AddCandidateFormWorkExperienceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
