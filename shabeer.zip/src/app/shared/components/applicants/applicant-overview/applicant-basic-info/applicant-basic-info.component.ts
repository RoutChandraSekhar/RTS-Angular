import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicant-basic-info',
  templateUrl: './applicant-basic-info.component.html',
  styleUrls: ['./applicant-basic-info.component.css']
})
export class ApplicantBasicInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
