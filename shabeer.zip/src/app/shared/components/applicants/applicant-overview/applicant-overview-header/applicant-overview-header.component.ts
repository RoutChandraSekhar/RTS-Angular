import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicant-overview-header',
  templateUrl: './applicant-overview-header.component.html',
  styleUrls: ['./applicant-overview-header.component.css']
})
export class ApplicantOverviewHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
