import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicant-overview',
  templateUrl: './applicant-overview.component.html',
  styleUrls: ['./applicant-overview.component.css']
})
export class ApplicantOverviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
