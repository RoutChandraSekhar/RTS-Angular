import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicant-education',
  templateUrl: './applicant-education.component.html',
  styleUrls: ['./applicant-education.component.css']
})
export class ApplicantEducationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
