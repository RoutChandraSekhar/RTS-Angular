import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicant-experience',
  templateUrl: './applicant-experience.component.html',
  styleUrls: ['./applicant-experience.component.css']
})
export class ApplicantExperienceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
