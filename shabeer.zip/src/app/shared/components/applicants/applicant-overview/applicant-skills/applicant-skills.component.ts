import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicant-skills',
  templateUrl: './applicant-skills.component.html',
  styleUrls: ['./applicant-skills.component.css']
})
export class ApplicantSkillsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
