import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicant-objective',
  templateUrl: './applicant-objective.component.html',
  styleUrls: ['./applicant-objective.component.css']
})
export class ApplicantObjectiveComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
