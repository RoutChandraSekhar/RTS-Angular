import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicant-contact-details',
  templateUrl: './applicant-contact-details.component.html',
  styleUrls: ['./applicant-contact-details.component.css']
})
export class ApplicantContactDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
