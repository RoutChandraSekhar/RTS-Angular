import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicant-timeline',
  templateUrl: './applicant-timeline.component.html',
  styleUrls: ['./applicant-timeline.component.css']
})
export class ApplicantTimelineComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
