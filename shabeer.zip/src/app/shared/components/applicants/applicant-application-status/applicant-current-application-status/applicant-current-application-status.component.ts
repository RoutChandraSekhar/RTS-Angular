import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicant-current-application-status',
  templateUrl: './applicant-current-application-status.component.html',
  styleUrls: ['./applicant-current-application-status.component.css']
})
export class ApplicantCurrentApplicationStatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
