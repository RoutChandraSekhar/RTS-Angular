import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicant-application-status',
  templateUrl: './applicant-application-status.component.html',
  styleUrls: ['./applicant-application-status.component.css']
})
export class ApplicantApplicationStatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
