import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicant-past-application-status',
  templateUrl: './applicant-past-application-status.component.html',
  styleUrls: ['./applicant-past-application-status.component.css']
})
export class ApplicantPastApplicationStatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
