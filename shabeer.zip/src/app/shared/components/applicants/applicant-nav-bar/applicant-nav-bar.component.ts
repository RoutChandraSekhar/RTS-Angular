import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicant-nav-bar',
  templateUrl: './applicant-nav-bar.component.html',
  styleUrls: ['./applicant-nav-bar.component.css']
})
export class ApplicantNavBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
