import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicant-job-title',
  templateUrl: './applicant-job-title.component.html',
  styleUrls: ['./applicant-job-title.component.css']
})
export class ApplicantJobTitleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
