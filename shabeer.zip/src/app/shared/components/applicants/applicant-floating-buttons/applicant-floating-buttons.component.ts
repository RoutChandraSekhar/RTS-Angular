import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicant-floating-buttons',
  templateUrl: './applicant-floating-buttons.component.html',
  styleUrls: ['./applicant-floating-buttons.component.css']
})
export class ApplicantFloatingButtonsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
