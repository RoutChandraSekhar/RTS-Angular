import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicant-title-info',
  templateUrl: './applicant-title-info.component.html',
  styleUrls: ['./applicant-title-info.component.css']
})
export class ApplicantTitleInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
