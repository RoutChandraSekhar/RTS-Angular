import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicant-application-log',
  templateUrl: './applicant-application-log.component.html',
  styleUrls: ['./applicant-application-log.component.css']
})
export class ApplicantApplicationLogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
