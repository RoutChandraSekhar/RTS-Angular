import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicant-documents',
  templateUrl: './applicant-documents.component.html',
  styleUrls: ['./applicant-documents.component.css']
})
export class ApplicantDocumentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
