export class Marks{
    Subject : string;
    Score : string;
    constructor(Subject:string, Score:string){
        this.Subject=Subject;
        this.Score=Score;
    }
}